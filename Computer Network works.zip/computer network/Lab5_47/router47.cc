#include <stdio.h>
#include <string.h>
#include <omnetpp.h>

#include "frame_47_m.h"

using namespace omnetpp;

class router47 : public cSimpleModule
{

  protected:

    virtual void forwardMessage(Frame47 *msg);

    virtual void initialize() override;

    virtual void handleMessage(cMessage *msg) override;

};

Define_Module(router47);

void router47::initialize()
{

}

void router47::handleMessage(cMessage *msg)
{

    Frame47 *ttmsg = check_and_cast<Frame47 *>(msg);

    forwardMessage(ttmsg);
}

void router47::forwardMessage(Frame47 *msg)
{

    // Increment hop count.
    msg->setHopCount(msg->getHopCount() + 1);



    // Same routing as before: random gate.
    int n = gateSize("gate");
    int k = intuniform(0, n - 1);

    cGate *arrivalGate = msg->getArrivalGate();


        if (arrivalGate != NULL)
        {
            int arrivalGateIndex = arrivalGate->getIndex();

            if (n >= 2)
            {
                while (arrivalGateIndex == k)
                {
                    k = intuniform(0,n-1);
                }
            }
        }

    EV << "Forwarding message " << msg << " on gate[" << k << "]\n";

    send(msg, "gate$o", k);
}
