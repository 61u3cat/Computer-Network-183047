#include <stdio.h>
#include <string.h>
#include <omnetpp.h>

using namespace omnetpp;

#include "frame_47_m.h"

class pc47 : public cSimpleModule
{
private:

    bool sender,receiver;

protected:

    virtual Frame47 *generateMessage();

    virtual void forwardMessage(Frame47 *msg);

    virtual void initialize() override;

    virtual void handleMessage(cMessage *msg) override;

};

Define_Module(pc47);

void pc47::initialize()
{

    sender=par("sendMsgOnInit");

        receiver=par("recvMsgAtDest");

            if (sender == true) {

               Frame47 *msg = generateMessage();

                send(msg, "interface$o");

            }

}

void pc47::handleMessage(cMessage *msg)
{
   Frame47 *ttmsg = check_and_cast<Frame47 *>(msg);

    if (receiver == true) {

        // Message arrived.

        EV << "Message " << ttmsg << " arrived after " << ttmsg->getHopCount() << " hops.\n";

        bubble("ARRIVED, Deleting Frame!");

        delete ttmsg;
}
    else {

        forwardMessage(ttmsg); // We need to forward the message.

    }
}

Frame47 *pc47::generateMessage()
{

    char msgname[20];

    sprintf(msgname,"FRAME47");

    // Create message object and set source and destination field.

   Frame47 *msg = new Frame47(msgname);

    return msg;

}

void pc47::forwardMessage(Frame47 *msg)
{

    // Increment hop count.

    msg->setHopCount(msg->getHopCount()+1);

    EV << "Forwarding back message " << msg << " on its interface "<<"\n";

    send(msg, "interface$o");

}
