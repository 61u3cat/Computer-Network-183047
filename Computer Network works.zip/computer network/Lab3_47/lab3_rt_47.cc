#include <stdio.h>
#include <string.h>
#include <omnetpp.h>

using namespace omnetpp;

class lab3_rt_47 : public cSimpleModule
{
  protected:
    virtual void forwardMessage(cMessage *msg);
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
};

Define_Module(lab3_rt_47);

void lab3_rt_47::initialize()
{

}

void lab3_rt_47::handleMessage(cMessage *msg)
{
        // We need to forward the message.
        forwardMessage(msg);
}

void lab3_rt_47::forwardMessage(cMessage *msg)
{
    // In this example, we just pick a random gate to send it on.
    // We draw a random number between 0 and the size of gate `gate[]'.
    int n = gateSize("gate");
    int k = intuniform(0, n-1);

    EV << "Forwarding message " << msg << " on gate[" << k << "]\n";
    // $o and $i suffix is used to identify the input/output part of a two way gate
    send(msg, "gate$o", k);
}
