#include <stdio.h>
#include <string.h>
#include <omnetpp.h>

using namespace omnetpp;

class lab3_pc_47 : public cSimpleModule
{
 protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
};

Define_Module(lab3_pc_47);

void lab3_pc_47::initialize()
{
    if (par("sendMsgOnInit").boolValue()==true)
    {
        EV << "Sending initial message\n";
        cMessage *msg = new cMessage("C183047_Lab3");
        send(msg, "interface$o");
    }

}

void lab3_pc_47::handleMessage(cMessage *msg) // will check whether the counter crossed the limit or not
{

            EV << getName() << "'s received , deleting message\n";
            delete msg;
}
